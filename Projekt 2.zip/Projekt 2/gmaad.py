import numpy as np
import matplotlib.pyplot as plt
from hmmlearn import hmm
import pandas as pd


df = pd.read_csv('house3_5devices_train.csv', delimiter=',')
data_lighting2 = np.array(df['lighting2'])

scores = list()
models = list()
aic = list()
bic = list()

for n_components in range(1, 20):
    for idx in range(10):  # ten different random starting states
        model = hmm.GaussianHMM(n_components=n_components, random_state=idx, n_iter=10)
        model.fit(data_lighting2[:, None])
        models.append(model)
        scores.append(model.score(data_lighting2[:, None]))
        aic.append(model.aic(data_lighting2[:, None]))
        bic.append(model.bic(data_lighting2[:, None]))

# get the best model
model = models[np.argmax(scores)]
print(f'The best model had a score of {max(scores)} and '
      f'{model.n_components} components')

#states = model.predict(data_lighting2[:, None])

# plot model states over time

plt.plot(aic, color="blue")
plt.plot(bic, color="green")
plt.show()

plt.plot(scores)
plt.show()