import pandas as pd
from hmmlearn import hmm
import numpy as np
import os
import argparse


def load_data(train_file):
    data = pd.read_csv(train_file, index_col=0)
    return data


def train_hmm(data, n_states):
    model = hmm.GaussianHMM(n_components=n_states, covariance_type="diag", n_iter=1000)
    model.fit(data)
    return model


def classify_device(test_file, models):
    data = pd.read_csv(test_file, index_col=0)
    scores = [model.score(data) for model in models]
    return np.argmax(scores)


def main(train_file, test_folder, output_file):
    train_data = load_data(train_file)
    models = []
    for column in train_data.columns:
        device_data = train_data[[column]].values
        model = train_hmm(device_data, n_states=4)  # Adjust the number of states as needed
        models.append(model)

    results = []
    for test_file in os.listdir(test_folder):
        if test_file.endswith(".csv"):
            device_idx = classify_device(os.path.join(test_folder, test_file), models)
            device_name = train_data.columns[device_idx]
            results.append((test_file, device_name))

    with open(output_file, 'w') as f:
        f.write("file,dev_classified\n")
        for test_file, device_name in results:
            f.write(f"{test_file},{device_name}\n")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--train", required=True, help="Path to the training data CSV file")
    parser.add_argument("--test", required=True, help="Path to the folder containing test CSV files")
    parser.add_argument("--output", required=True, help="Path to the output file")
    args = parser.parse_args()
    main(args.train, args.test, args.output)
